import java.util.Scanner;

public class PrimeiraCalculadora {
	public static void main(String[] args) {
		menu();
		

	}
	
	public static void menu() {
		Scanner entradaUsuario = new Scanner(System.in);
		System.out.println("Digite a operação desejada: ");
	    System.out.println("1 - Soma ");	
	    System.out.println("2 - Divisão");
	    System.out.println("3 - Subtração");
	    System.out.println("4 - Multiplicação");
	    
	    int operação = entradaUsuario.nextInt();
	    
	    if (operação == 1) {
	    	soma();
	    }
	    if (operação == 2) {
	    divisão();	
	    }
	    if (operação == 3) {
	    subtração();
	    }
	    if (operação == 4) {
	    multiplicação();	
	    }
	   
	
	}

	public static void soma() {

		Scanner entradaUsuario = new Scanner(System.in);

		System.out.println("Digite o primeiro valor: ");
		int primeiroValor = entradaUsuario.nextInt();

		System.out.println("Digite o segundo valor: ");
		int segundoValor = entradaUsuario.nextInt();

		int resultado = primeiroValor + segundoValor;
		System.out.println("O Resultado da soma é: " + resultado);
		entradaUsuario.close();

	}

	public static void divisão() {

		Scanner entradaUsuario = new Scanner(System.in);

		System.out.println("Digite o primeiro valor: ");
		int primeiroValor = entradaUsuario.nextInt();

		System.out.println("Digite o segundo valor: ");
		int segundoValor = entradaUsuario.nextInt();

		int resultado = primeiroValor / segundoValor;
		System.out.println("O Resultado da divisão é: " + resultado);
		entradaUsuario.close();

	}
	
	public static void subtração() {
		
		Scanner entradaUsuario = new Scanner(System.in);

		System.out.println("Digite o primeiro valor: ");
		int primeiroValor = entradaUsuario.nextInt();

		System.out.println("Digite o segundo valor: ");
		int segundoValor = entradaUsuario.nextInt();

		int resultado = primeiroValor - segundoValor;
		System.out.println("O Resultado da subtração é: " + resultado);	
		entradaUsuario.close();
	}
	
	public static void multiplicação() {
		
		Scanner entradaUsuario = new Scanner(System.in);

		System.out.println("Digite o primeiro valor: ");
		int primeiroValor = entradaUsuario.nextInt();

		System.out.println("Digite o segundo valor: ");
		int segundoValor = entradaUsuario.nextInt();

		int resultado = primeiroValor * segundoValor;
		System.out.println("O Resultado da multiplicação é: " + resultado);
		
		entradaUsuario.close();
	}
	
	

}
